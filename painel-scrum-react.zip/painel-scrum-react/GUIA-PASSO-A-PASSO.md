# Guia passo a passo — Windows CMD

## 1. Conferir Node e npm

Abra o **Prompt de Comando (CMD)** e execute:

```bat
node -v
npm -v
```

Use Node 20.19+ ou 22.12+.

## 2. Opção mais fácil: usar este projeto pronto

Extraia a pasta `painel-scrum-react` para a Área de Trabalho e execute:

```bat
cd %USERPROFILE%\Desktop\painel-scrum-react
npm install
npm run dev
```

Abra no navegador o endereço exibido no CMD.

## 3. Se quiser criar a estrutura do zero com Vite

```bat
cd %USERPROFILE%\Desktop
npm create vite@latest painel-scrum-react -- --template react
cd painel-scrum-react
npm install
npm install xlsx
```

O Vite cria a pasta `src` automaticamente.

Crie as subpastas:

```bat
mkdir src\components
mkdir src\components\common
mkdir src\components\tabs
mkdir src\context
mkdir src\data
mkdir src\utils
mkdir src\styles
mkdir public\images
mkdir public\data
```

Depois copie os arquivos deste projeto pronto para os mesmos caminhos.

## 4. Rodar o sistema

```bat
npm run dev
```

## 5. Testar build antes da entrega

Pare o servidor com `Ctrl + C` e execute:

```bat
npm run build
```

Se terminar sem erros, teste:

```bat
npm run preview
```

A pasta `dist` é gerada automaticamente e NÃO deve ser enviada ao GitHub.

## 6. Criar repositório Git

Dentro da pasta do projeto:

```bat
git init
git add .
git commit -m "Cria estrutura inicial do projeto React"
```

Crie um repositório vazio no GitHub. Depois use os comandos mostrados pelo próprio GitHub, normalmente:

```bat
git branch -M main
git remote add origin URL_DO_SEU_REPOSITORIO
git push -u origin main
```

## 7. Commits durante o trabalho

Não faça apenas um commit final. Exemplos:

```bat
git add .
git commit -m "Implementa abas de avaliação"
git push
```

```bat
git add .
git commit -m "Adiciona autosave e importação JSON"
git push
```

```bat
git add .
git commit -m "Finaliza escalação e resultado final"
git push
```

Cada integrante deve fazer contribuições reais e commits próprios.

## 8. Publicar no Netlify

1. Entre no Netlify.
2. Escolha **Add new site / Import an existing project**.
3. Conecte o GitHub.
4. Selecione o repositório.
5. Build command: `npm run build`.
6. Publish directory: `dist`.
7. Faça o deploy.
8. Teste o link publicado.
9. Envie o link do Netlify na atividade, junto do link do GitHub se solicitado.

O arquivo `netlify.toml` deste projeto já contém essas configurações.

## 9. Testes obrigatórios antes da entrega

- Alterar turma e data.
- Renomear as duas empresas e conferir as outras abas.
- Atribuir alunos a todos os tipos de papel.
- Conferir a aba Escalação.
- Preencher notas em todas as abas.
- Testar corrupção e sabotagem.
- Conferir o Resultado Final.
- Atualizar a página e confirmar que os dados voltaram do localStorage.
- Clicar em Salvar agora.
- Exportar JSON.
- Limpar dados e depois carregar o JSON exportado.
- Importar a planilha `alunos.xlsx`.
- Testar A− / A / A+.
- Executar `npm run build` sem erros.
- Conferir que `node_modules` e `dist` NÃO estão no GitHub.
